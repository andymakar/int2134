package groupproject;

import java.util.Date;

public class Show {

    String title, type, address;
    Date performanceDate, bookingDate;
    Double fee;
    int clientNum;

    public Show() {
        title = null;
        type = null;
        performanceDate = null;
        bookingDate = null;
        address = null;
        fee = 0.0;
        clientNum = 0;
    }

    public Show(String t, String ty, String a, Date p, Date b, Double f, int n) {
        title = t;
        type = ty;
        address = a;
        performanceDate = p;
        bookingDate = b;
        fee = f;
        clientNum = n;
    }

    public void setTitle(String t) {
        title = t;
    }

    public void setType(String ty) {
        type = ty;
    }

    public void setAddress(String a) {
        address = a;
    }

    public void setPerformanceDate(Date p) {
        performanceDate = p;
    }
    public void setBookingDate(Date p) {
        bookingDate = p;
    }
    public void setFee(Double f) {
        fee = f;
    }
    public void setClientNum(int n) {
        clientNum = n;
    }
    public String getTitle() {
        return title;
    }
    public String getType() {
        return type;
    }
    public String getAddress() {
        return address;
    }
    public Date getPerformanceDate() {
        return performanceDate;
    }
    public Date getBookingDate() {
        return bookingDate;
    }
    public Double getFee() {
        return fee;
    }
    public int getClientNum() {
        return clientNum;
    }
}
