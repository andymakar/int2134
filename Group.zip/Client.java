package groupproject;

public class Client {

    String firstName, lastName, phoneNumber, address;
    int clientNum;

    public Client() {
        firstName = null;
        lastName = null;
        phoneNumber = null;
        address = null;
        clientNum = 0;
    }

    public Client(String f, String l, String p, String a, int n) {
        firstName = f;
        lastName = l;
        phoneNumber = p;
        address = a;
        clientNum = n;
    }

    public void setFirstName(String f) {
        firstName = f;
    }

    public void setLastName(String l) {
        lastName = l;
    }

    public void setPhone(String p) {
        phoneNumber = p;
    }

    public void setAddress(String a) {
        address = a;
    }

    public void setNum(int n) {
        clientNum = n;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public int getNum() {
        return clientNum;
    }
}
