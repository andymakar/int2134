package groupproject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class GroupProject {

    public static ArrayList<Client> clientList = new ArrayList<Client>();
    public static ArrayList<Show> showList = new ArrayList<Show>();
    public static SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
    
    public static void main(String[] args) {
        Scanner localScanner = new Scanner(System.in);
        int j;
        char c;
        do {
            printMenu();
            c = localScanner.next().charAt(0);
            c = Character.toUpperCase(c);
            switch (c) {
                case 'A':
                    addClient();
                    break;
                case 'B':
                    System.out.print("Enter client id to update: ");
                    j = localScanner.nextInt();
                    updateClient(j);
                    break;
                case 'C':
                    System.out.print("Enter client id to delete from: ");
                    j = localScanner.nextInt();
                    deleteClient(j);
                    break;
                case 'D':
                    addShow();
                    break;
                case 'E':
                    System.out.print("Enter show id to delete from: ");
                    j = localScanner.nextInt();
                    deleteShow(j);
                    break;
                case 'F':
                    System.out.print("Enter show id to update: ");
                    j = localScanner.nextInt();
                    updateShow(j);
                    break;
                case 'G':
                    clientList();
                    break;
                case 'H':
                    System.out.println("Enter month of shows to list: ");
                    String month = localScanner.nextLine();
                    System.out.println("Enter year of shows to list: ");
                    String year = localScanner.nextLine();
                    showList(month, year);
                    break;
                case 'Q':
                    System.out.println("Exiting program.  Goodbye");
                    break;
                default:
                    System.out.println("Please select a valid choice");
            }
        } while (c != 'Q');
    }

    public static void printMenu() {
        System.out.println("\nKapoof Entertainment Booking System");
        System.out.println("-------------------");
        System.out.println("\nPlease select from the following options:");
        System.out.println("(A) Add a Client");
        System.out.println("(B) Update a Client");
        System.out.println("(C) Delete a Client");
        System.out.println("(D) Add a Show");
        System.out.println("(E) Delete a Show");
        System.out.println("(F) Update a Show");
        System.out.println("(G) Report: List of Clients");
        System.out.println("(H) Report: List of Shows");
        System.out.println("(Q) Quit");
        System.out.print("\nPlease enter a selection: ");
    }

    private static void addClient() {
        Scanner localScanner = new Scanner(System.in);
        Client newClient = new Client();
        System.out.print("Enter client first name: ");
        newClient.setFirstName(localScanner.nextLine());
        System.out.print("Enter client last name: ");
        newClient.setLastName(localScanner.nextLine());
        System.out.print("Enter client phone number: ");
        newClient.setPhone(localScanner.nextLine());
        System.out.print("Enter client address: ");
        newClient.setAddress(localScanner.nextLine());
        clientList.add(newClient);
    }

    public static void updateClient(int num) {
        Scanner localScanner = new Scanner(System.in);
        System.out.println("Which of the following client properties would you like to update?");
        System.out.println("(A) First name");
        System.out.println("(B) Last name");
        System.out.println("(C) Phone number");
        System.out.println("(D) Address");
        System.out.print("\nPlease enter a selection: ");
        char c;
            c = localScanner.nextLine().charAt(0);
            c = Character.toUpperCase(c);
            switch (c) {
                case 'A':
                    System.out.print("Enter new first name for client num " + num + ": ");
                    clientList.get(num).setFirstName(localScanner.nextLine());
                    break;
                case 'B':
                    System.out.print("Enter new last name for client num " + num + ": ");
                    clientList.get(num).setLastName(localScanner.nextLine());
                    break;
                case 'C':
                    System.out.print("Enter new phone number for client num " + num + ": ");
                    clientList.get(num).setPhone(localScanner.nextLine());
                    break;
                case 'D':
                    System.out.print("Enter new address for client num " + num + ": ");
                    clientList.get(num).setAddress(localScanner.nextLine());
                    break;
                default:
                    System.out.println("Please select a valid choice");
            }
    }

    public static void deleteClient(int num) {
        Scanner localScanner = new Scanner(System.in);
        System.out.println("Which of the following client properties would you like to delete?");
        System.out.println("(A) First name");
        System.out.println("(B) Last name");
        System.out.println("(C) Phone number");
        System.out.println("(D) Address");
        System.out.println("(E) Delete entire client listing");
        System.out.print("\nPlease enter a selection: ");
        char c;
            c = localScanner.nextLine().charAt(0);
            c = Character.toUpperCase(c);
            switch (c) {
                case 'A':
                    clientList.get(num).setFirstName(null);
                    System.out.println("Deleting client first name");
                    break;
                case 'B':
                    clientList.get(num).setLastName(null);
                    System.out.println("Deleting client last name");
                    break;
                case 'C':
                    clientList.get(num).setPhone(null);
                    System.out.println("Deleting client phone number");
                    break;
                case 'D':
                    clientList.get(num).setAddress(null);
                    System.out.println("Deleting client address");
                    break;
                case 'E':
                    clientList.get(num).setFirstName(null);
                    clientList.get(num).setLastName(null);
                    clientList.get(num).setPhone(null);
                    clientList.get(num).setAddress(null);
                    System.out.println("Deleting all client " + num + " properties");
                    break;
                default:
                    System.out.println("Please select a valid choice");
            }
    }

    private static void addShow() {
        Scanner localScanner = new Scanner(System.in);
        Show newShow = new Show();
        System.out.print("Enter show title: ");
        newShow.setTitle(localScanner.nextLine());
        System.out.print("Enter show type (magic show, comedian show, or rock band): ");
        newShow.setType(localScanner.nextLine());
        System.out.print("Enter show performance date in the form (yyyy/MM/dd): ");
        try {
            newShow.setPerformanceDate(formatter.parse(localScanner.nextLine()));
        } catch (ParseException e) {
            System.err.println("Error setting performance date");
            e.printStackTrace();
        }
        System.out.print("Enter show booking date in the form (yyyy/MM/dd): ");
        try {
            newShow.setBookingDate(formatter.parse(localScanner.nextLine()));
        } catch (ParseException e) {
            System.err.println("Error setting booking date");
            e.printStackTrace();
        }
        System.out.print("Enter show fee: ");
        newShow.setFee(localScanner.nextDouble());
        System.out.print("Enter show address (Include address, city, state, and zip): ");
        newShow.setAddress(localScanner.nextLine());
        showList.add(newShow);
    }

    public static void deleteShow(int num) {
        Scanner localScanner = new Scanner(System.in);
        System.out.println("Which of the following show properties would you like to delete?");
        System.out.println("(A) Title");
        System.out.println("(B) Type");
        System.out.println("(C) Performance Date");
        System.out.println("(D) Booking Date");
        System.out.println("(E) Fee");
        System.out.println("(F) Address");
        System.out.println("(G) Delete entire show listing");
        System.out.print("\nPlease enter a selection: ");
        char c;
            c = localScanner.nextLine().charAt(0);
            c = Character.toUpperCase(c);
            switch (c) {
                case 'A':
                    showList.get(num).setTitle(null);
                    System.out.println("Deleting show title");
                    break;
                case 'B':
                    showList.get(num).setType(null);
                    System.out.println("Deleting show type");
                    break;
                case 'C':
                    showList.get(num).setPerformanceDate(null);
                    System.out.println("Deleting show performance date");
                    break;
                case 'D':
                    showList.get(num).setBookingDate(null);
                    System.out.println("Deleting client booking date");
                    break;
                case 'E':
                    showList.get(num).setFee(null);
                    System.out.println("Deleting fee");
                case 'F':
                    showList.get(num).setAddress(null);
                    System.out.println("Deleting client address");
                case 'G':
                    showList.get(num).setTitle(null);
                    showList.get(num).setType(null);
                    showList.get(num).setPerformanceDate(null);
                    showList.get(num).setBookingDate(null);
                    showList.get(num).setFee(null);
                    showList.get(num).setAddress(null);
                    System.out.println("Deleting all show " + num + " properties");
                    break;
                default:
                    System.out.println("Please select a valid choice");
            }
    }

    public static void updateShow(int num) {
        Scanner localScanner = new Scanner(System.in);
        System.out.println("Which of the following show properties would you like to update?");
        System.out.println("(A) Title");
        System.out.println("(B) Type");
        System.out.println("(C) Performance Date");
        System.out.println("(D) Booking Date");
        System.out.println("(E) Fee");
        System.out.println("(F) Address");
        System.out.println("(G) Update entire show listing");
        System.out.print("\nPlease enter a selection: ");
        char c;
            c = localScanner.nextLine().charAt(0);
            c = Character.toUpperCase(c);
            switch (c) {
                case 'A':
                    System.out.print("Enter new title for show num " + num + ": ");
                    showList.get(num).setTitle(localScanner.nextLine());
                    break;
                case 'B':
                    System.out.print("Enter new type for show num " + num + ": ");
                    showList.get(num).setType(localScanner.nextLine());
                    break;
                case 'C':
                    System.out.print("Enter new show performance date in the form (yyyy/MM/dd): ");
                    try {
                        showList.get(num).setPerformanceDate(formatter.parse(localScanner.nextLine()));
                    } catch (ParseException e) {
                        System.err.println("Error setting performance date");
                        e.printStackTrace();
                    }
                    break;
                case 'D':
                    System.out.print("Enter new show booking date in the form (yyyy/MM/dd): ");
                    try {
                        showList.get(num).setBookingDate(formatter.parse(localScanner.nextLine()));
                    } catch (ParseException e) {
                        System.err.println("Error setting booking date");
                        e.printStackTrace();
                    }
                    break;
                case 'E':
                    System.out.print("Enter new fee for show num " + num + ": ");
                    showList.get(num).setFee(localScanner.nextDouble());
                case 'F':
                    System.out.print("Enter new show address (Include address, city, state, and zip): ");
                    showList.get(num).setAddress(localScanner.nextLine());

                case 'G':
                    System.out.print("Enter new title for show num " + num + ": ");
                    showList.get(num).setTitle(localScanner.nextLine());
                    System.out.print("Enter new type for show num " + num + ": ");
                    showList.get(num).setType(localScanner.nextLine());
                    System.out.print("Enter new show performance date in the form (yyyy/MM/dd): ");
                    try {
                        showList.get(num).setPerformanceDate(formatter.parse(localScanner.nextLine()));
                    } catch (ParseException e) {
                        System.err.println("Error setting performance date");
                        e.printStackTrace();
                    }
                    System.out.print("Enter new show booking date in the form (yyyy/MM/dd): ");
                    try {
                        showList.get(num).setBookingDate(formatter.parse(localScanner.nextLine()));
                    } catch (ParseException e) {
                        System.err.println("Error setting booking date");
                        e.printStackTrace();
                    }
                    System.out.print("Enter new fee for show num " + num + ": ");
                    showList.get(num).setFee(localScanner.nextDouble());
                    System.out.print("Enter new show address (Include address, city, state, and zip): ");
                    showList.get(num).setAddress(localScanner.nextLine());
                    break;
                default:
                    System.out.println("Please select a valid choice");
            }
    }

    public static void clientList() {
        Date date = new Date();
        System.out.println("List of Clients (Client Num. First name_Last name, phone number, address)");
        System.out.println("Report created on: " + formatter.format(date));
        System.out.println("-------------------");
        for (int i = 0; i < clientList.size(); i++) {
            if (clientList.get(i) != null) {
                System.out.println(i + ". " + clientList.get(i).getFirstName() + " " + clientList.get(i).getLastName() + ", " + clientList.get(i).getPhone() + ", " + clientList.get(i).getAddress());
            }
        }
    }

    public static void showList(String month, String year) {
        Date date = new Date();
        System.out.println("List of Shows in" + month + " of " + year + "(Show num, Show title, Show Date, Client First Name and Last Name, Show Type, Show fee)");
        System.out.println("Report created on: " + formatter.format(date));
        System.out.println("-------------------");
        for (int i = 0; i < showList.size(); i++) {
            if (showList.get(i) != null) {
                System.out.println(i + ". " + showList.get(i).getTitle()+ ", " + showList.get(i).getPerformanceDate().toString() + ", " + clientList.get(showList.get(i).getClientNum()).getFirstName() + " " + clientList.get(showList.get(i).getClientNum()).getLastName() + ", " + showList.get(i).getType());
            }
        }
    }
}
